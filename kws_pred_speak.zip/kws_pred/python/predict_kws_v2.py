import tensorflow as tf
from tensorflow import keras
import scipy.io.wavfile
import numpy as np
import math
from scipy.fftpack import dct
import os

pre_emphasis = 0.97
frame_length_len = 512
frame_shift_len = 256

os.environ["CUDA_VISIBLE_DEVICES"]="-1"

def delta(feat, N):
    if N < 1:
        raise ValueError('N must be an integer >= 1')
    NUMFRAMES = len(feat)
    denominator = 2 * sum([i**2 for i in range(1, N+1)])
    delta_feat = np.empty_like(feat)
    padded = np.pad(feat, ((N, N), (0, 0)), mode='edge')   # padded version of feat
    for t in range(NUMFRAMES):
        delta_feat[t] = np.dot(np.arange(-N, N+1), padded[t : t+2*N+1]) / denominator   # [t : t+2*N+1] == [(N+t)-N : (N+t)+N+1]
    return delta_feat


def extract_mfcc(input_signal, sample_rate):
    input_signal = input_signal / 32768
    # 预加重 y(t)=x(t)−αx(t−1)
    emphasized_signal = np.append(input_signal[0], input_signal[1:] - pre_emphasis * input_signal[:-1])
    # 分帧
    frame_length = frame_length_len
    frame_step = frame_shift_len

    signal_length = len(emphasized_signal)
    frame_length = int(round(frame_length))
    frame_step = int(round(frame_step))
    num_frames = int(np.ceil(float(np.abs(signal_length - frame_length)) / frame_step + 1))

    pad_signal_length = num_frames * frame_step + frame_length
    z = np.zeros((pad_signal_length - signal_length))
    pad_signal = np.append(emphasized_signal, z)

    indices = np.tile(np.arange(0, frame_length), (num_frames, 1)) + \
              np.tile(np.arange(0, num_frames * frame_step, frame_step), (frame_length, 1)).T

    frames = pad_signal[np.mat(indices).astype(np.int32, copy=False)]

    # 加窗
    frames *= np.hamming(frame_length)

    # 傅里叶变换np
    # 傅立叶变换和功率谱
    NFFT = frame_length_len
    mag_frames = np.absolute(np.fft.rfft(frames, NFFT))  # Magnitude of the FFT
    # print(mag_frames.shape)
    pow_frames = ((1.0 / NFFT) * (mag_frames ** 2))  # Power Spectrum

    # 三角滤波
    low_freq_mel = 0
    # 将频率转换为Mel
    nfilt = 40  # mel滤波器组：40个滤波器
    a = 1 + (sample_rate / 2) / 700
    high_freq_mel = (2595 * math.log10(1 + (sample_rate / 2) / 700))
    mel_points = np.linspace(low_freq_mel, high_freq_mel, nfilt + 2)  # Equally spaced in Mel scale
    hz_points = (700 * (10 ** (mel_points / 2595) - 1))  # Convert Mel to Hz

    bin = np.floor((NFFT + 1) * hz_points / sample_rate)

    fbank = np.zeros((nfilt, int(np.floor(NFFT / 2 + 1))))

    for m in range(1, nfilt + 1):
        f_m_minus = int(bin[m - 1])  # left
        f_m = int(bin[m])  # center
        f_m_plus = int(bin[m + 1])  # right
        for k in range(f_m_minus, f_m):
            fbank[m - 1, k] = (k - bin[m - 1]) / (bin[m] - bin[m - 1])
        for k in range(f_m, f_m_plus):
            fbank[m - 1, k] = (bin[m + 1] - k) / (bin[m + 1] - bin[m])
    filter_banks = np.dot(pow_frames, fbank.T)
    filter_banks = np.where(filter_banks == 0, np.finfo(float).eps, filter_banks)  # Numerical Stability
    filter_banks = 20 * np.log10(filter_banks)  # dB

    # 用离散余弦变换（DCT）对滤波器组系数去相关处理，并产生滤波器组的压缩表示
    num_ceps = 12
    mfcc = dct(filter_banks, type=2, axis=1, norm='ortho')[:, 1: (num_ceps + 1)]  # 保持在2-13

    # 将正弦升降1应用于MFCC以降低已被声称在噪声信号中改善语音识别的较高MFCC.
    (nframes, ncoeff) = mfcc.shape
    n = np.arange(ncoeff)
    cep_lifter = 22
    lift = 1 + (cep_lifter / 2) * np.sin(np.pi * n / cep_lifter)
    mfcc *= lift

    # 一阶二阶差分提取
    mfcc_delta1 = delta(mfcc, 1)
    mfcc_delta2 = delta(mfcc, 2)
    return mfcc, mfcc_delta1, mfcc_delta2

# 预测单个文件
def prediction_single_file(filename):
    sample_rate, wave_data = scipy.io.wavfile.read(filename)

    mfcc, delta1, delta2 = extract_mfcc(wave_data, sample_rate)
    mfcc_feat = np.hstack((mfcc, delta1, delta2))
    mfcc_features = np.reshape(mfcc_feat, [218, 36])

    input_wav = tf.expand_dims(mfcc_features, axis=0)
    input_wav = tf.expand_dims(input_wav, axis=3)
    predictions = model.predict(input_wav)
    score = tf.nn.softmax(predictions[0])

    predict_cls = np.argmax(score)
    predict_scr = np.max(score)
    return predict_cls, predict_scr


# 预测目录下所有音频文件
def prediction_multi_file(src_dir):
    cnt = 0
    wav_files = os.listdir(src_dir)
    with open("./predict_result.txt", "w") as f:
        for _, wav_file in enumerate(wav_files):
            full_wav_path = src_dir + wav_file
            pre_cls, pre_scr = prediction_single_file(full_wav_path)
            info = wav_file + " " + str(pre_cls) + " " + str(pre_scr) + "\n"    # 一行：文件名 预测类别 概率
            f.write(info)
            cnt = cnt + 1
            print("current index of :", cnt)
    f.close()


if __name__ == '__main__':

    """加载模型"""
    model = keras.models.load_model("./cnn_kws_v2.h5")

    """单个音频文件识别"""
    test_filename = "../val/0/background_0.wav"  # 指定音频文件路径
    pre_cls, pre_scr = prediction_single_file(test_filename)
    print("类别：%s, 概率：%s" % (pre_cls, pre_scr))  # 类别对应的概率大于0.5即可认为正确

    """识别目录下所有音频文件，结果写入txt文件"""
    # wav_dir = "../val/0/"
    # prediction_multi_file(wav_dir)


